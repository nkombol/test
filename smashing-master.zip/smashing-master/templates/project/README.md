Check out http://smashing.github.io/smashing for more information.
